import { PassThrough, Writable } from "node:stream";
export declare class FfiRuntimeHost {
    private readonly libraryPath;
    private readonly cliEntrypoint;
    private readonly environment;
    private readonly args;
    private static readonly quarantinedHosts;
    private readonly lib;
    private serverId;
    private connectionId;
    private disposed;
    private starting;
    private outboundCallback;
    private keepAliveTimer;
    private cleanupRetryTimer;
    private cleanupInProgress;
    /** The stream JSON-RPC reads server→client frames from. */
    readonly receiveStream: PassThrough;
    /** The stream JSON-RPC writes client→server frames to. */
    readonly sendStream: Writable;
    private constructor();
    /**
     * Loads the runtime cdylib at the given path and prepares the FFI host.
     */
    static create(libraryPath: string, cliEntrypoint: string | undefined, environment: Record<string, string | undefined> | undefined, args: readonly string[]): FfiRuntimeHost;
    /** Starts the in-process Rust runtime and opens the FFI JSON-RPC connection. */
    start(): Promise<void>;
    private writeFrame;
    /**
     * Native outbound (server→client) callback. koffi delivers it on the JS event loop
     * via a threadsafe function, so the frame is decoded and written straight to
     * {@link receiveStream}. The native pointer is only valid for this call, so the
     * bytes are copied out before returning.
     */
    private feedInbound;
    private unregisterCallback;
    private scheduleCleanupRetry;
    private tryFinalizeCleanup;
    /** Awaits the initial cleanup attempt; a non-quiescent close is retried in the background. */
    dispose(): Promise<void>;
}
