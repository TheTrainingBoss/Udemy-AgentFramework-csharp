export declare const COPILOT_CLI_VERSION = "1.0.84-5";
export declare const COPILOT_CLI_USE_NPM_PACKAGE = false;
